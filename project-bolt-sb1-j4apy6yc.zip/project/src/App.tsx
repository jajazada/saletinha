import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { UtensilsCrossed, Wine, Leaf } from "lucide-react";

interface MenuItem {
  name: string;
  description: string;
  price: number;
  isVegetarian?: boolean;
}

interface MenuSection {
  title: string;
  items: MenuItem[];
}

const menu: MenuSection[] = [
  {
    title: "Para Começar",
    items: [
      {
        name: "Carpaccio de Filé Mignon",
        description: "Finas fatias de filé mignon, rúcula, parmesão e molho de mostarda dijon",
        price: 45.00
      },
      {
        name: "Bruschetta de Tomates Heirloom",
        description: "Pão artesanal grelhado, tomates frescos, manjericão e azeite de oliva extravirgem",
        price: 32.00,
        isVegetarian: true
      },
      {
        name: "Bolinhos de Bacalhau",
        description: "Crocantes por fora, macios por dentro, acompanhados de maionese de ervas",
        price: 38.00
      }
    ]
  },
  {
    title: "Pratos Principais",
    items: [
      {
        name: "Risoto de Cogumelos Silvestres",
        description: "Arroz arbório, mix de cogumelos, vinho branco e trufa negra",
        price: 78.00,
        isVegetarian: true
      },
      {
        name: "Filé Mignon ao Molho de Vinho Tinto",
        description: "Acompanha purê de batatas e legumes grelhados",
        price: 120.00
      },
      {
        name: "Peixe Grelhado com Molho de Maracujá",
        description: "Filé de peixe fresco grelhado, molho cítrico de maracujá, arroz integral e legumes no vapor",
        price: 95.00
      }
    ]
  },
  {
    title: "Sobremesas",
    items: [
      {
        name: "Cheesecake de Frutas Vermelhas",
        description: "Base crocante de biscoito, creme de queijo suave e calda de frutas vermelhas",
        price: 28.00
      },
      {
        name: "Petit Gateau",
        description: "Bolinho de chocolate com casca crocante e recheio cremoso, acompanhado de sorvete de baunilha",
        price: 32.00
      },
      {
        name: "Pudim de Leite Condensado",
        description: "Clássico pudim de leite com calda de caramelo",
        price: 22.00
      }
    ]
  },
  {
    title: "Bebidas",
    items: [
      {
        name: "Vinho Tinto Malbec",
        description: "Argentina",
        price: 120.00
      },
      {
        name: "Vinho Branco Sauvignon Blanc",
        description: "Chile",
        price: 110.00
      },
      {
        name: "Caipirinha de Frutas Vermelhas",
        description: "Vodka premium, frutas vermelhas frescas e açúcar",
        price: 25.00
      },
      {
        name: "Mojito Clássico",
        description: "Rum, hortelã fresca, limão e água com gás",
        price: 28.00
      }
    ]
  }
];

function App() {
  return (
    <div className="min-h-screen bg-[#f8f5f2] text-gray-800 py-12 px-4">
      <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-xl overflow-hidden">
        {/* Header */}
        <div className="relative h-64 bg-gradient-to-r from-emerald-800 to-emerald-600 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/20" />
          <div className="relative text-center text-white">
            <UtensilsCrossed className="mx-auto mb-4 h-12 w-12" />
            <h1 className="font-serif text-5xl font-bold mb-2">Saletinha</h1>
            <p className="text-lg italic">Sabores que encantam, momentos que ficam</p>
          </div>
        </div>

        {/* Menu Content */}
        <ScrollArea className="h-[calc(100vh-16rem)] px-8 py-12">
          {menu.map((section, index) => (
            <div key={section.title} className="mb-12 last:mb-0">
              <div className="flex items-center gap-2 mb-6">
                {index === 0 && <UtensilsCrossed className="h-5 w-5 text-emerald-600" />}
                {index === 1 && <UtensilsCrossed className="h-5 w-5 text-emerald-600" />}
                {index === 2 && <UtensilsCrossed className="h-5 w-5 text-emerald-600" />}
                {index === 3 && <Wine className="h-5 w-5 text-emerald-600" />}
                <h2 className="text-2xl font-semibold text-gray-800">{section.title}</h2>
              </div>
              
              <div className="space-y-6">
                {section.items.map((item) => (
                  <div key={item.name} className="group">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h3 className="text-lg font-medium text-gray-800 group-hover:text-emerald-600 transition-colors">
                            {item.name}
                          </h3>
                          {item.isVegetarian && (
                            <Leaf className="h-4 w-4 text-green-500" />
                          )}
                        </div>
                        <p className="mt-1 text-sm text-gray-600">{item.description}</p>
                      </div>
                      <span className="text-lg font-medium text-emerald-600">
                        R$ {item.price.toFixed(2)}
                      </span>
                    </div>
                    <Separator className="mt-4" />
                  </div>
                ))}
              </div>
            </div>
          ))}

          {/* Footer */}
          <div className="text-center mt-12 pt-8 border-t border-gray-200">
            <p className="text-sm text-gray-600 italic">
              "No Saletinha, cada prato é uma história, cada momento é especial. Obrigado por fazer parte da nossa mesa!"
            </p>
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}

export default App;